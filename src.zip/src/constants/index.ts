export const LEAD_STATUSES = ['new', 'contacted', 'qualified', 'lost'] as const;
export const USER_ROLES = ['admin', 'sales'] as const;
export const LEAD_SOURCES = ['referral', 'ads', 'website', 'other'] as const;